<style>
  .ranking-table td,
  .ranking-table th { vertical-align: middle; }
  .rank-row-1 { background-color: #fffbeb !important; }
  .rank-row-2 { background-color: #f8fafc !important; }
  .rank-row-3 { background-color: #fdf4ec !important; }
  .rank-medal { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; font-size: 12.5px; font-weight: 700; white-space: nowrap; }
  .rank-gold { background-color: #fef3c7; color: #92400e; }
  .rank-silver { background-color: #e5e7eb; color: #374151; }
  .rank-bronze { background-color: #fed7aa; color: #9a3412; }
  .rank-number { display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; border-radius: 50%; background-color: #f1f3f9; color: #4b5563; font-weight: 700; font-size: 13px; }
  .panel-chips { display: flex; flex-wrap: wrap; gap: 5px; }
  .panel-chip { background-color: #eef2ff; color: #4f46e5; border-radius: 50px; padding: 3px 12px; font-size: 12px; font-weight: 500; white-space: nowrap; }
  .status-pill { display: inline-flex; align-items: center; padding: 5px 14px; border-radius: 50px; font-size: 12px; font-weight: 600; }
  .status-danger { background-color: #fef2f2; color: #ef4444; }
  .status-pending { background-color: #f1f3f9; color: #6b7280; }
  .markah-value { font-size: 15px; font-weight: 700; color: #16a34a; }
</style>
