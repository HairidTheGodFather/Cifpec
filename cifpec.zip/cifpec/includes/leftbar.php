<!-- ============================================================== -->
<!-- left sidebar -->
<!-- ============================================================== -->
<div class="nav-left-sidebar sidebar-dark">
    <div class="menu-list">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
            <button
                class="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target="#navbarNav"
                aria-controls="navbarNav"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
 
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav flex-column">
                    <li class="nav-divider">Menu</li>
 
                    <li class="nav-item">
                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'halaman-utama.php' ? 'active' : '' ?>"
                            href="halaman-utama.php">
                            <i class="fa fa-fw fa-home"></i>Halaman Utama
                        </a>
                    </li>
 
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'pelajar.php' ? 'active' : '' ?>"
                                href="pelajar.php">
                                <i class="fa fa-fw fa-user"></i>Pelajar
                            </a>
                        </li>
 
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'kumpulan.php' ? 'active' : '' ?>"
                                href="kumpulan.php">
                                <i class="fa fa-fw fa-users"></i>Kumpulan
                            </a>
                        </li>
 
                        <?php
                        $halamanSemasa = basename($_SERVER['PHP_SELF']);
                        $jenisSemasa = (isset($_GET['jenis']) && $_GET['jenis'] === 'projek') ? 'projek' : 'poster';
                        ?>
                        <li class="nav-item">
                            <a class="nav-link <?= ($halamanSemasa == 'senarai-panel.php' && $jenisSemasa == 'projek') ? 'active' : '' ?>"
                                href="senarai-panel.php?jenis=projek">
                                <i class="fas fa-fw fa-table"></i>Senarai Hakim untuk Projek
                            </a>
                        </li>
 
                        <li class="nav-item">
                            <a class="nav-link <?= ($halamanSemasa == 'senarai-panel.php' && $jenisSemasa == 'poster') ? 'active' : '' ?>"
                                href="senarai-panel.php?jenis=poster">
                                <i class="fas fa-fw fa-table"></i>Senarai Panel untuk Poster
                            </a>
                        </li>
 
                        <?php
                        $halamanMarkah = ['ranking-poster.php', 'ranking-keseluruhan.php', 'ranking-kursus.php', 'top3-kursus.php'];
                        $dalamMarkah = in_array(basename($_SERVER['PHP_SELF']), $halamanMarkah);
                        ?>
                        <li class="nav-item">
                            <a
                                class="nav-link <?= $dalamMarkah ? 'active' : '' ?>"
                                href="#"
                                data-toggle="collapse"
                                aria-expanded="<?= $dalamMarkah ? 'true' : 'false' ?>"
                                data-target="#submenu-3"
                                aria-controls="submenu-3">
                                <i class="fas fa-fw fa-print"></i>Markah
                            </a>
 
                            <div id="submenu-3" class="collapse submenu <?= $dalamMarkah ? 'show' : '' ?>">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'ranking-poster.php' ? 'active' : '' ?>"
                                            href="ranking-poster.php">Ranking poster</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'ranking-keseluruhan.php' ? 'active' : '' ?>"
                                            href="ranking-keseluruhan.php">Ranking keseluruhan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'ranking-kursus.php' ? 'active' : '' ?>"
                                            href="ranking-kursus.php">Ranking Mengikut Kursus</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'top3-kursus.php' ? 'active' : '' ?>"
                                            href="top3-kursus.php">Top 3 Mengikut Kursus</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
 
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'hakim'): ?>
                        <!-- NILAI MARKAH: 2 SOALAN -->
                        <li class="nav-item">
                            <a
                                class="nav-link <?= basename($_SERVER['PHP_SELF']) == 'nilai-markah.php' ? 'active' : '' ?>"
                                href="#"
                                data-toggle="collapse"
                                aria-expanded="<?= basename($_SERVER['PHP_SELF']) == 'nilai-markah.php' ? 'true' : 'false' ?>"
                                data-target="#submenu-nilai-markah"
                                aria-controls="submenu-nilai-markah">
                                <i class="fas fa-fw fa-inbox"></i>Nilai Markah
                            </a>
 
                            <div id="submenu-nilai-markah"
                                class="collapse submenu <?= basename($_SERVER['PHP_SELF']) == 'nilai-markah.php' ? 'show' : '' ?>">
                                <ul class="nav flex-column">
                                    <li class="nav-item">
                                        <a class="nav-link"
                                            href="nilai-markah.php?soalan=1">
                                            Soalan 1 - Poster Projek
                                        </a>
                                    </li>
 
                                    <li class="nav-item">
                                        <a class="nav-link"
                                            href="nilai-markah.php?soalan=2">
                                            Soalan 2 - Penilaian Projek
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                    <?php endif; ?>
 
                    <li class="nav-item">
                        <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutConfirmModal">
                            <i class="fas fa-fw fa-power-off"></i>Logout
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- ============================================================== -->
<!-- end left sidebar -->
<!-- ============================================================== -->
 
<!-- Modal Confirmation Logout -->
<div class="modal fade" id="logoutConfirmModal" tabindex="-1" role="dialog" aria-labelledby="logoutConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content logout-modal-content">
            <div class="modal-body text-center">
                <div class="logout-icon-wrap">
                    <i class="fas fa-power-off"></i>
                </div>
                <h5 class="mt-3 mb-2">Log Keluar?</h5>
                <p class="text-muted mb-0">Adakah anda pasti mahu log keluar daripada sistem ini?</p>
            </div>
            <div class="modal-footer justify-content-center border-0 pb-4">
                <a href="#" class="btn btn-logout-cancel" data-dismiss="modal">Batal</a>
                <a href="includes/logout.php" class="btn btn-logout-confirm">Ya, Log Keluar</a>
            </div>
        </div>
    </div>
</div>
 
<style>
    .logout-modal-content {
        border: none;
        border-radius: 16px;
        overflow: hidden;
    }
 
    .logout-icon-wrap {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background-color: #fef2f2;
        color: #ef4444;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        margin: 8px auto 0;
    }
 
    .btn-logout-cancel,
    .btn-logout-confirm {
        border: none;
        border-radius: 50px;
        padding: 8px 22px;
        font-size: 13.5px;
        font-weight: 600;
        cursor: pointer;
        transition: transform .1s ease, box-shadow .15s ease;
        text-decoration: none;
    }
 
    .btn-logout-cancel {
        background-color: #f1f3f9;
        color: #374151;
    }
 
    .btn-logout-cancel:hover {
        background-color: #e5e7eb;
        color: #374151;
        text-decoration: none;
    }
 
    .btn-logout-confirm {
        background-color: #ef4444;
        color: #ffffff;
        box-shadow: 0 4px 12px rgba(239, 68, 68, .35);
    }
 
    .btn-logout-confirm:hover {
        background-color: #dc2626;
        color: #ffffff;
        text-decoration: none;
        transform: translateY(-1px);
    }
 
    .btn-logout-cancel:active,
    .btn-logout-confirm:active {
        transform: scale(.96);
    }
</style>
 
<script>
    // Alihkan modal ke <body> supaya tidak terperangkap dalam overflow/z-index sidebar.
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('logoutConfirmModal');
        if (modal && modal.parentElement !== document.body) {
            document.body.appendChild(modal);
        }
    });
</script>