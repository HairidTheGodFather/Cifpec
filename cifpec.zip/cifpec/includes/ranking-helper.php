<?php
// Fungsi kongsi untuk halaman ranking (poster, keseluruhan, kursus, top 3)

// $jenis = 'poster' (jadual markah_poster sahaja) atau 'keseluruhan' (poster + projek)
// Markah setiap bahagian = purata markah daripada hakim yang sudah menilai.
function ambilRanking($conn, $jenis)
{
  $sql = "
    SELECT
      k.id_kumpulan, k.tajuk, k.nama_penyelia,
      pl.nama_pelajar AS ketua, pl.kursus,
      po.jumlah AS jumlah_poster, po.bil AS bil_poster, po.panel AS panel_poster,
      pr.jumlah AS jumlah_projek, pr.bil AS bil_projek, pr.panel AS panel_projek
    FROM kumpulan k
    LEFT JOIN pelajar pl ON pl.id_pelajar = k.id_ketua_kumpulan
    LEFT JOIN (
      SELECT p.id_kumpulan, SUM(m.markah) AS jumlah,
             COUNT(DISTINCT m.id_penilaian) AS bil,
             GROUP_CONCAT(DISTINCT u.name SEPARATOR ', ') AS panel
      FROM penilaian_poster p
      INNER JOIN markah_poster m ON m.id_penilaian = p.id_penilaian
      INNER JOIN users u ON u.id = p.id_penilai
      GROUP BY p.id_kumpulan
    ) po ON po.id_kumpulan = k.id_kumpulan
    LEFT JOIN (
      SELECT p.id_kumpulan, SUM(m.markah) AS jumlah,
             COUNT(DISTINCT m.id_penilaian) AS bil,
             GROUP_CONCAT(DISTINCT u.name SEPARATOR ', ') AS panel
      FROM penilaian p
      INNER JOIN markah m ON m.id_penilaian = p.id_penilaian
      INNER JOIN users u ON u.id = p.id_penilai
      GROUP BY p.id_kumpulan
    ) pr ON pr.id_kumpulan = k.id_kumpulan
  ";

  $result = $conn->query($sql);
  $rows = [];
  while ($r = $result->fetch_assoc()) {
    $markahPoster = ((int) $r['bil_poster'] > 0) ? ((float) $r['jumlah_poster'] / (int) $r['bil_poster']) : 0;
    $markahProjek = ((int) $r['bil_projek'] > 0) ? ((float) $r['jumlah_projek'] / (int) $r['bil_projek']) : 0;

    if ($jenis === 'poster') {
      $r['markah'] = $markahPoster;
      $panel = $r['panel_poster'];
    } else {
      $r['markah'] = $markahPoster + $markahProjek;
      $gabung = array_filter(array_merge(
        $r['panel_poster'] ? explode(', ', $r['panel_poster']) : [],
        $r['panel_projek'] ? explode(', ', $r['panel_projek']) : []
      ));
      $panel = implode(', ', array_unique($gabung));
    }

    $r['panel_names'] = $panel;
    $r['kursus'] = $r['kursus'] ?: 'Tiada Kursus';
    $rows[] = $r;
  }

  usort($rows, function ($a, $b) {
    if ($a['markah'] == $b['markah']) return strcmp($a['tajuk'], $b['tajuk']);
    return $a['markah'] < $b['markah'] ? 1 : -1;
  });

  return tetapkanRank($rows);
}

// Markah sama = ranking sama
function tetapkanRank($rows)
{
  $pos = 0;
  $rankSemasa = 0;
  $markahLepas = null;
  foreach ($rows as $i => $r) {
    $pos++;
    if ($markahLepas === null || round($r['markah'], 2) != round($markahLepas, 2)) {
      $rankSemasa = $pos;
    }
    $rows[$i]['rank'] = $rankSemasa;
    $markahLepas = $r['markah'];
  }
  return $rows;
}

// Kumpulkan ikut kursus, ranking dikira semula dalam setiap kursus
function kumpulkanIkutKursus($rows)
{
  $group = [];
  foreach ($rows as $r) {
    $group[$r['kursus']][] = $r;
  }
  ksort($group);
  foreach ($group as $kursus => $senarai) {
    $group[$kursus] = tetapkanRank($senarai);
  }
  return $group;
}

function lencanaRank($rank)
{
  switch ($rank) {
    case 1:
      return '<span class="rank-medal rank-gold">🥇 <span>Emas</span></span>';
    case 2:
      return '<span class="rank-medal rank-silver">🥈 <span>Perak</span></span>';
    case 3:
      return '<span class="rank-medal rank-bronze">🥉 <span>Gangsa</span></span>';
    default:
      return '<span class="rank-number">' . (int) $rank . '</span>';
  }
}

// Paparkan jadual ranking. $maksimum = markah penuh, $had = hadkan bilangan baris (top 3)
function paparTabelRanking($rows, $maksimum, $had = null)
{
  if ($had !== null) {
    // Top N: buang yang belum dinilai, ambil yang rank <= $had
    $rows = array_values(array_filter($rows, function ($r) use ($had) {
      return $r['markah'] > 0 && $r['rank'] <= $had;
    }));
  }
?>
  <div class="table-responsive">
    <table class="table table-striped table-bordered ranking-table">
      <thead class="thead-dark">
        <tr>
          <th>Ranking</th>
          <th>Booth / Kumpulan</th>
          <th>Ketua Kumpulan</th>
          <th>Kursus</th>
          <th>Nama Penyelia PTA</th>
          <th>Panel Yang Menilai</th>
          <th>Markah (Purata / <?= (int) $maksimum ?>)</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($rows)): ?>
          <tr>
            <td colspan="7" class="text-center text-muted">Tiada data untuk dipaparkan.</td>
          </tr>
        <?php endif; ?>
        <?php foreach ($rows as $item): ?>
          <tr class="<?= $item['markah'] > 0 && $item['rank'] <= 3 ? 'rank-row-' . $item['rank'] : '' ?>">
            <td><?= $item['markah'] > 0 ? lencanaRank($item['rank']) : '<span class="rank-number">-</span>' ?></td>
            <td><strong><?= htmlspecialchars($item['tajuk']) ?></strong></td>
            <td><?= htmlspecialchars($item['ketua'] ?? '') ?></td>
            <td><?= htmlspecialchars($item['kursus']) ?></td>
            <td><?= htmlspecialchars($item['nama_penyelia']) ?></td>
            <td>
              <?php if (!empty($item['panel_names'])): ?>
                <div class="panel-chips">
                  <?php foreach (explode(', ', $item['panel_names']) as $panel): ?>
                    <span class="panel-chip"><?= htmlspecialchars($panel) ?></span>
                  <?php endforeach; ?>
                </div>
              <?php else: ?>
                <span class="status-pill status-pending">Tiada Penilai</span>
              <?php endif; ?>
            </td>
            <td>
              <?= $item['markah'] > 0
                ? '<span class="markah-value">' . number_format($item['markah'], 2) . '</span>'
                : '<span class="status-pill status-danger">Belum Dinilai</span>' ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php
}
