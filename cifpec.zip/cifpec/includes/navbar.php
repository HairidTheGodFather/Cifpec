 <!-- ============================================================== -->
 <!-- navbar -->
 <!-- ============================================================== -->
 <div class="dashboard-header">
     <style>
         .navbar-toggler-icon {
             background-image: url("data:image/svg+xml;charset=utf8,%3Csvg viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath stroke='rgba%280, 0, 0, 0.5%29' stroke-width='2' stroke-linecap='round' stroke-miterlimit='10' d='M4 7h22M4 15h22M4 23h22'/%3E%3C/svg%3E");
         }
     </style>
     <nav class="navbar navbar-expand-lg bg-white fixed-top">
         <span class="navbar-brand" href="dashboard.php">CIFPECScore</span>
         <button
             class="navbar-toggler"
             type="button"
             data-toggle="collapse"
             data-target="#navbarSupportedContent"
             aria-controls="navbarSupportedContent"
             aria-expanded="false"
             aria-label="Toggle navigation">
             <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarSupportedContent">

             <ul class="navbar-nav ml-auto navbar-right-top">
                 <li class="nav-item dropdown nav-user">
                     <a
                         class="nav-link nav-user-img"
                         href="#"
                         id="navbarDropdownMenuLink2"
                         data-toggle="dropdown"
                         aria-haspopup="true"
                         aria-expanded="false"><img
                             src="assets/images/profile.jpg"
                             alt=""
                             class="user-avatar-md rounded-circle" /></a>
                     <div
                         class="dropdown-menu dropdown-menu-right nav-user-dropdown"
                         aria-labelledby="navbarDropdownMenuLink2">
                         <div class="nav-user-info">
                             <h5 class="mb-0 text-white nav-user-name"><?= strtoupper(htmlspecialchars($_SESSION['name'])) ?></h5>
                             <span class="status"></span><span class="ml-2">Role: <?= strtoupper(htmlspecialchars($_SESSION['role'])) ?></span>
                         </div>
                         <a class="dropdown-item" href="includes/logout.php"><i class="fas fa-power-off mr-2"></i>Logout</a>
                     </div>
                 </li>
             </ul>
         </div>
     </nav>
 </div>
 <!-- ============================================================== -->
 <!-- end navbar -->
 <!-- ============================================================== -->