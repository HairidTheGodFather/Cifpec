<?php
// Perlukan PHPMailer. Pasang dahulu di root projek anda:
//   composer require phpmailer/phpmailer
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// ============================================
// TUKAR maklumat SMTP anda di bawah ini
// ============================================
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_USERNAME', 'hazerulhairid2008@gmail.com');      // <-- TUKAR
define('SMTP_PASSWORD', 'rwue nmfu tjuq qyyg');    // <-- TUKAR (Gmail App Password, BUKAN password login biasa)
define('SMTP_PORT', 587);
define('SMTP_FROM_EMAIL', 'hazerulhairid2008@gmail.com');    // <-- TUKAR
define('SMTP_FROM_NAME', 'CIFPECScore');

/**
 * Hantar kod OTP ke emel penerima.
 *
 * @param string $toEmail
 * @param string $toName
 * @param string $otp
 * @return bool true jika berjaya dihantar, false jika gagal
 */
function sendOTPEmail(string $toEmail, string $toName, string $otp): bool
{
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = SMTP_PORT;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = 'Kod Pengesahan OTP - CIFPECScore';
        $safeName = htmlspecialchars($toName);
        $mail->Body = "
            <div style='font-family: Arial, sans-serif; padding: 20px;'>
                <h2>Salam, {$safeName}</h2>
                <p>Kod OTP anda untuk pendaftaran akaun CIFPECScore ialah:</p>
                <h1 style='letter-spacing: 8px; color:#4f46e5;'>{$otp}</h1>
                <p>Kod ini sah selama <b>5 minit</b> sahaja.</p>
                <p style='color:#888; font-size:12px;'>Jika anda tidak memohon kod ini, sila abaikan emel ini.</p>
            </div>
        ";
        $mail->AltBody = "Kod OTP anda ialah: {$otp} (Sah selama 5 minit)";

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer Error: ' . $mail->ErrorInfo);
        return false;
    }
}